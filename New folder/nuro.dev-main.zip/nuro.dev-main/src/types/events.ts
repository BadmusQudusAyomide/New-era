// @TODO: Add Xmas type with snowing effect
export enum EventType {
	BIRTHDAY = 'birthday',
}
