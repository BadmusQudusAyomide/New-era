export interface Settings {
	animations: boolean | null;
	sound: boolean;
}
