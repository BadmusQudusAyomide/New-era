export { Icon } from './Icon.component';
export { Standard } from './Standard.component';
export { Outline } from './Outline.component';
