/**
 * Note: This styling system is very hacky & not ideal.
 * A new & better system for prose / code block styles needs to be looked into in future
 */
export { CodeStyles as Code } from './Code.styles';
export { ElementsStyles as Elements } from './Elements.styles';
