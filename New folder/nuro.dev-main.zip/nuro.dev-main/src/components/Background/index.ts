import { Standard } from './Standard.component';

export { Standard } from './Standard.component';

export default Standard;
